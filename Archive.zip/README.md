# addeventlistener

> Personal page built on vue.js

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).

Note from me: This setup includes Sass. See here: http://sass-lang.com/
You can start the server with npm run dev
another resource that you might want to look at is:
https://vuejs.org/v2/guide/deployment.html
https://vuejs.org/v2/guide/routing.html




ADD LINKEDIN AND GITHUB LINKS
YOU CAN ALSO ADD MORE EXPERIENCE FROM YOUR LINKEDIN PROFILE
